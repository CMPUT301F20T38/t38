package com.example.booker.data;

public class BorrowBook extends Book {
    public BorrowBook(String author, String title, String ISBN, String status, String owner, String borrower) {
        super(author, title, ISBN, status, owner, borrower);
    }
}
